

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;


	@WebServlet("/LoginServlet")
	public class LoginServlet extends HttpServlet {
	    private static final long serialVersionUID = 1L;

	    protected void doPost(HttpServletRequest request, HttpServletResponse response)
	            throws ServletException, IOException {
	        String username = request.getParameter("username");
	        String password = request.getParameter("password");

	        // Check login credentials
	        boolean isValidUser = authenticateUser(username, password);

	        if (isValidUser) {
	            // Redirect to the welcome page upon successful login
	            response.sendRedirect("welcome.jsp");
	        } else {
	            // Send response to the client for unsuccessful login
	            response.setContentType("text/html");
	            PrintWriter out = response.getWriter();
	            out.println("<h2>Login failed. Invalid username or password.</h2>");
	        }
	    }

	    private boolean authenticateUser(String username, String password) {
	        // Hardcoded authentication for demonstration purposes
	        return "Hamit".equals(username) && "Hamit12".equals(password);
	    }
	    
	    
}
