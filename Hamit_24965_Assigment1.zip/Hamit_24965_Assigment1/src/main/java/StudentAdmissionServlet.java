

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;


public class StudentAdmissionServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    
    public StudentAdmissionServlet() {
        super();
        // TODO Auto-generated constructor stub
    }


	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String studentName = request.getParameter("studentName");
        String admissionNumber = request.getParameter("admissionNumber");
        String course = request.getParameter("course");

        
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();
        out.println("<html>");
        out.println("<head>");
        out.println("<title>Student Admission Preview</title>");
        out.println("<link rel=\"stylesheet\" type=\"text/css\" href=\"styles.css\">");
        out.println("</head>");
        out.println("<body>");
        out.println("<h1>Student Admission Preview</h1>");
        out.println("<p><strong>Name:</strong> " + studentName + "</p>");
        out.println("<p><strong>Admission Number:</strong> " + admissionNumber + "</p>");
        out.println("<p><strong>Course:</strong> " + course + "</p>");
        out.println("</body>");
        out.println("</html>");
		
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	   
	    String admissionPageUrl = "/student_admission.html"; 
	    
	    response.sendRedirect(admissionPageUrl);
	}

}
