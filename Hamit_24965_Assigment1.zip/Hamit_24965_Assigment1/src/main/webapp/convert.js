function convertNumber() {
    var decimal = document.getElementById("decimal").value;
    var conversionType = document.getElementById("conversionType").value;

    fetch("NumberConvertor?decimal=" + decimal + "&conversionType=" + conversionType)
        .then(response => response.text())
        .then(data => {
            document.getElementById("result").innerHTML = data;
        })
        .catch(error => console.error('Error:', error));
}
