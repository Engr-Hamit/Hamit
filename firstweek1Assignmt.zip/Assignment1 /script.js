function validateForm() {
  var username = document.getElementById("username").value;
  var password = document.getElementById("password").value;
  var errorMessage = document.getElementById("error-message");

  if (username === "Hamit" && password === "Kader12") {
      
      window.location.href = "register.html"; 
      return false; 
  }
  
  errorMessage.textContent = "Invalid username or password!";
  
  document.getElementById("password").value = "";

  return false;
}
