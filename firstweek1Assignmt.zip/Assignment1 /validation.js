function validateForm() {
  var firstName = document.getElementById('firstName').value;
  var lastName = document.getElementById('lastName').value;
  var email = document.getElementById('email').value;
  var phoneNumber = document.getElementById('phoneNumber').value;
  var address = document.getElementById('address').value;
  var dateOfBirth = document.getElementById('dateOfBirth').value;
  var gender = document.getElementById('gender').value;
  var department = document.getElementById('department').value;
  var position = document.getElementById('position').value;
  var startDate = document.getElementById('startDate').value;
  var salary = document.getElementById('salary').value;
  var employeeId = document.getElementById('employeeId').value;

  if (
      firstName === '' || lastName === '' || email === '' || phoneNumber === '' ||
      address === '' || dateOfBirth === '' || gender === '' || department === '' ||
      position === '' || startDate === '' || salary === '' || employeeId === ''
  ) {
      alert('All fields must be filled out');
      return false;
  }

  // You can add additional validation logic here

  return true;
}
